/* tslint:disable */
require("./RenderProfilePicture.module.css");
const styles = {
  personaCard: 'personaCard_451c58b7'
};

export default styles;
/* tslint:enable */