/* tslint:disable */
require("./Spfxpersona.module.css");
const styles = {
  spfxpersona: 'spfxpersona_f5d5a5c0',
  container: 'container_f5d5a5c0',
  row: 'row_f5d5a5c0',
  column: 'column_f5d5a5c0',
  'ms-Grid': 'ms-Grid_f5d5a5c0',
  title: 'title_f5d5a5c0',
  subTitle: 'subTitle_f5d5a5c0',
  description: 'description_f5d5a5c0',
  button: 'button_f5d5a5c0',
  label: 'label_f5d5a5c0'
};

export default styles;
/* tslint:enable */