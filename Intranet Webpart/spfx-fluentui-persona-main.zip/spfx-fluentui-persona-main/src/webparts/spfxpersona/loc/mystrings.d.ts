declare interface ISpfxpersonaWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'SpfxpersonaWebPartStrings' {
  const strings: ISpfxpersonaWebPartStrings;
  export = strings;
}
