declare const styles: {
    personaCard: string;
};
export default styles;
//# sourceMappingURL=RenderProfilePicture.module.scss.d.ts.map