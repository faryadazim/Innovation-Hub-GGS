interface IProfilePicProps {
    developerName: string;
    title: string;
    getUserProfileUrl?: () => Promise<string>;
}
export declare function RenderProfilePicture(props: IProfilePicProps): JSX.Element;
export {};
//# sourceMappingURL=RenderProfilePicture.d.ts.map