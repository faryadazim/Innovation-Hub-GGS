import * as React from 'react';
import { ISpfxpersonaProps } from './ISpfxpersonaProps';
export interface ISpfxpersonaWebPartState {
    ProductionBoardDevelopers: any[];
}
export default class Spfxpersona extends React.Component<ISpfxpersonaProps, ISpfxpersonaWebPartState> {
    constructor(props: ISpfxpersonaProps);
    private getUserProfileUrl;
    private getNextWeekDates;
    private getCurrentWeekDates;
    private getNextWeekNumberAndYear;
    getProductionBoardDevelopers(): Promise<void>;
    componentDidMount(): void;
    render(): React.ReactElement<ISpfxpersonaProps>;
}
//# sourceMappingURL=Spfxpersona.d.ts.map