define("5c351123-eb58-4835-8c6c-dd34b3bb236d_0.0.1", ["GgsaInnovationhubHelpingWebPartStrings","@microsoft/sp-property-pane","@microsoft/sp-core-library","@microsoft/sp-webpart-base","react","react-dom"], function(__WEBPACK_EXTERNAL_MODULE__0jj2__, __WEBPACK_EXTERNAL_MODULE__26ea__, __WEBPACK_EXTERNAL_MODULE_UWqr__, __WEBPACK_EXTERNAL_MODULE_br4S__, __WEBPACK_EXTERNAL_MODULE_cDcd__, __WEBPACK_EXTERNAL_MODULE_faye__) { return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "Wft9");
/******/ })
/************************************************************************/
/******/ ({

/***/ "0jj2":
/*!*********************************************************!*\
  !*** external "GgsaInnovationhubHelpingWebPartStrings" ***!
  \*********************************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE__0jj2__;

/***/ }),

/***/ "26ea":
/*!**********************************************!*\
  !*** external "@microsoft/sp-property-pane" ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE__26ea__;

/***/ }),

/***/ "UWqr":
/*!*********************************************!*\
  !*** external "@microsoft/sp-core-library" ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_UWqr__;

/***/ }),

/***/ "Wft9":
/*!**********************************************************************************!*\
  !*** ./lib/webparts/ggsaInnovationhubHelping/GgsaInnovationhubHelpingWebPart.js ***!
  \**********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react-dom */ "faye");
/* harmony import */ var react_dom__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react_dom__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @microsoft/sp-core-library */ "UWqr");
/* harmony import */ var _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @microsoft/sp-property-pane */ "26ea");
/* harmony import */ var _microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @microsoft/sp-webpart-base */ "br4S");
/* harmony import */ var _microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! GgsaInnovationhubHelpingWebPartStrings */ "0jj2");
/* harmony import */ var GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _components_GgsaInnovationhubHelping__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./components/GgsaInnovationhubHelping */ "mhxQ");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();







var GgsaInnovationhubHelpingWebPart = /** @class */ (function (_super) {
    __extends(GgsaInnovationhubHelpingWebPart, _super);
    function GgsaInnovationhubHelpingWebPart() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        _this._isDarkTheme = false;
        _this._environmentMessage = '';
        return _this;
    }
    GgsaInnovationhubHelpingWebPart.prototype.render = function () {
        var element = react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_components_GgsaInnovationhubHelping__WEBPACK_IMPORTED_MODULE_6__["default"], {
            description: this.properties.description,
            isDarkTheme: this._isDarkTheme,
            environmentMessage: this._environmentMessage,
            hasTeamsContext: !!this.context.sdks.microsoftTeams,
            userDisplayName: this.context.pageContext.user.displayName
        });
        react_dom__WEBPACK_IMPORTED_MODULE_1__["render"](element, this.domElement);
    };
    GgsaInnovationhubHelpingWebPart.prototype.onInit = function () {
        var _this = this;
        return this._getEnvironmentMessage().then(function (message) {
            _this._environmentMessage = message;
        });
    };
    GgsaInnovationhubHelpingWebPart.prototype._getEnvironmentMessage = function () {
        var _this = this;
        if (!!this.context.sdks.microsoftTeams) { // running in Teams, office.com or Outlook
            return this.context.sdks.microsoftTeams.teamsJs.app.getContext()
                .then(function (context) {
                var environmentMessage = '';
                switch (context.app.host.name) {
                    case 'Office': // running in Office
                        environmentMessage = _this.context.isServedFromLocalhost ? GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["AppLocalEnvironmentOffice"] : GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["AppOfficeEnvironment"];
                        break;
                    case 'Outlook': // running in Outlook
                        environmentMessage = _this.context.isServedFromLocalhost ? GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["AppLocalEnvironmentOutlook"] : GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["AppOutlookEnvironment"];
                        break;
                    case 'Teams': // running in Teams
                        environmentMessage = _this.context.isServedFromLocalhost ? GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["AppLocalEnvironmentTeams"] : GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["AppTeamsTabEnvironment"];
                        break;
                    default:
                        throw new Error('Unknown host');
                }
                return environmentMessage;
            });
        }
        return Promise.resolve(this.context.isServedFromLocalhost ? GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["AppLocalEnvironmentSharePoint"] : GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["AppSharePointEnvironment"]);
    };
    GgsaInnovationhubHelpingWebPart.prototype.onThemeChanged = function (currentTheme) {
        if (!currentTheme) {
            return;
        }
        this._isDarkTheme = !!currentTheme.isInverted;
        var semanticColors = currentTheme.semanticColors;
        if (semanticColors) {
            this.domElement.style.setProperty('--bodyText', semanticColors.bodyText || null);
            this.domElement.style.setProperty('--link', semanticColors.link || null);
            this.domElement.style.setProperty('--linkHovered', semanticColors.linkHovered || null);
        }
    };
    GgsaInnovationhubHelpingWebPart.prototype.onDispose = function () {
        react_dom__WEBPACK_IMPORTED_MODULE_1__["unmountComponentAtNode"](this.domElement);
    };
    Object.defineProperty(GgsaInnovationhubHelpingWebPart.prototype, "dataVersion", {
        get: function () {
            return _microsoft_sp_core_library__WEBPACK_IMPORTED_MODULE_2__["Version"].parse('1.0');
        },
        enumerable: false,
        configurable: true
    });
    GgsaInnovationhubHelpingWebPart.prototype.getPropertyPaneConfiguration = function () {
        return {
            pages: [
                {
                    header: {
                        description: GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["PropertyPaneDescription"]
                    },
                    groups: [
                        {
                            groupName: GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["BasicGroupName"],
                            groupFields: [
                                Object(_microsoft_sp_property_pane__WEBPACK_IMPORTED_MODULE_3__["PropertyPaneTextField"])('description', {
                                    label: GgsaInnovationhubHelpingWebPartStrings__WEBPACK_IMPORTED_MODULE_5__["DescriptionFieldLabel"]
                                })
                            ]
                        }
                    ]
                }
            ]
        };
    };
    return GgsaInnovationhubHelpingWebPart;
}(_microsoft_sp_webpart_base__WEBPACK_IMPORTED_MODULE_4__["BaseClientSideWebPart"]));
/* harmony default export */ __webpack_exports__["default"] = (GgsaInnovationhubHelpingWebPart);


/***/ }),

/***/ "br4S":
/*!*********************************************!*\
  !*** external "@microsoft/sp-webpart-base" ***!
  \*********************************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_br4S__;

/***/ }),

/***/ "cDcd":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_cDcd__;

/***/ }),

/***/ "faye":
/*!****************************!*\
  !*** external "react-dom" ***!
  \****************************/
/*! no static exports found */
/***/ (function(module, exports) {

module.exports = __WEBPACK_EXTERNAL_MODULE_faye__;

/***/ }),

/***/ "krra":
/*!****************************************************************************!*\
  !*** ./lib/webparts/ggsaInnovationhubHelping/components/MainComponents.js ***!
  \****************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
var __awaiter = (undefined && undefined.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (undefined && undefined.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};

var MainComponents = function () {
    var _a = react__WEBPACK_IMPORTED_MODULE_0__["useState"](""), pgeSwitch = _a[0], setPageSwitch = _a[1];
    var _b = react__WEBPACK_IMPORTED_MODULE_0__["useState"]([]), businessAreaWise = _b[0], setBusinessAreaWise = _b[1];
    var _c = react__WEBPACK_IMPORTED_MODULE_0__["useState"]([]), productionBoard = _c[0], setProductionBoard = _c[1];
    var pageFunction = function () { return __awaiter(void 0, void 0, void 0, function () {
        var urlParams, pageName, webURL, ap_list, numberOfItems, endpointUrl, headers, adp_list, endpointUrl2;
        return __generator(this, function (_a) {
            urlParams = new URLSearchParams(window.location.search);
            pageName = urlParams.get("Page");
            webURL = "https://ggsaus.sharepoint.com";
            ap_list = "Annual Plan";
            numberOfItems = 5000;
            endpointUrl = "".concat(webURL, "/_api/web/lists/getbytitle('").concat(ap_list, "')/items?$top=").concat(numberOfItems);
            headers = new Headers();
            headers.append("Accept", "application/json;odata=verbose");
            fetch(endpointUrl, {
                method: "GET",
                headers: headers
            })
                .then(function (response) { return response.json(); })
                .then(function (res) {
                var _a;
                var data = (_a = res === null || res === void 0 ? void 0 : res.d) === null || _a === void 0 ? void 0 : _a.results;
                var countsMap = new Map();
                data.forEach(function (item) {
                    var BusinessArea = item.BusinessArea, Status = item.Status;
                    var lowercaseStatus = Status.toLowerCase();
                    if (countsMap.has(BusinessArea)) {
                        var statusCounts = countsMap.get(BusinessArea);
                        statusCounts[lowercaseStatus] += 1;
                    }
                    else {
                        countsMap.set(BusinessArea, {
                            completed: lowercaseStatus === "completed" ? 1 : 0,
                            behind_schedule: lowercaseStatus === "behind schedule" ? 1 : 0,
                            scheduled: lowercaseStatus === "scheduled" ? 1 : 0,
                        });
                    }
                });
                var displayData = [];
                countsMap.forEach(function (statusCounts, businessArea) {
                    var completed = statusCounts.completed, behind_schedule = statusCounts.behind_schedule, scheduled = statusCounts.scheduled;
                    displayData.push({
                        businessArea: businessArea,
                        completed: completed,
                        behind_schedule: behind_schedule,
                        scheduled: scheduled
                    });
                });
                setBusinessAreaWise(displayData);
            })
                .catch(function (error) {
                // Handle any errors
                console.error("Error:", error);
            });
            adp_list = "Activity Delivery Plan";
            endpointUrl2 = "".concat(webURL, "/_api/web/lists/getbytitle('").concat(adp_list, "')/items?$orderby=Modified desc&$top=").concat(numberOfItems);
            fetch(endpointUrl2, {
                method: "GET",
                headers: headers
            })
                .then(function (response) { return response.json(); })
                .then(function (res) {
                var _a;
                var data = (_a = res === null || res === void 0 ? void 0 : res.d) === null || _a === void 0 ? void 0 : _a.results;
                var currentDate = new Date();
                var currentWeek = getWeekNumber(currentDate);
                function getWeekNumber(date) {
                    var d = new Date(date);
                    d.setHours(0, 0, 0, 0);
                    d.setDate(d.getDate() + 4 - (d.getDay() || 7));
                    var yearStart = new Date(d.getFullYear(), 0, 1);
                    var weekNo = Math.ceil(((d - yearStart) / 86400000 + 1) / 7);
                    return weekNo;
                }
                var filteredData = data.filter(function (obj) {
                    var StartDate = new Date(obj.StartDate);
                    var EndDate = new Date(obj.EndDate);
                    var startWeek = getWeekNumber(StartDate);
                    var endWeek = getWeekNumber(EndDate);
                    var isInCurrentWeek = currentWeek >= startWeek && currentWeek <= endWeek;
                    var isPhZero = obj.ph === 0;
                    return isInCurrentWeek && isPhZero;
                });
                var uniqueArray = [];
                var uniqueNames = {};
                for (var _i = 0, filteredData_1 = filteredData; _i < filteredData_1.length; _i++) {
                    var item = filteredData_1[_i];
                    if (item === null || item === void 0 ? void 0 : item.DeveloperId) {
                        var DeveloperId = item.DeveloperId;
                        if (!uniqueNames[DeveloperId]) {
                            uniqueNames[DeveloperId] = true;
                            uniqueArray.push(item);
                        }
                    }
                }
                console.log(uniqueArray, "---", uniqueNames);
                console.log(uniqueArray);
                setProductionBoard(uniqueArray);
            })
                .catch(function (error) {
                // Handle any errors
                console.error("Error:", error);
            });
            if (pageName == "INV") {
                setPageSwitch("INV");
            }
            else {
                setPageSwitch("PR");
            }
            return [2 /*return*/];
        });
    }); };
    react__WEBPACK_IMPORTED_MODULE_0__["useEffect"](function () {
        pageFunction();
    }, []);
    return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null, pgeSwitch == "INV" ? react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null,
        react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null,
            react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h3", null, "Innovation Hub"),
            react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("table", { style: { borderCollapse: 'collapse', width: '100%' } },
                react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("thead", null,
                    react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("tr", null,
                        react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("th", { style: { padding: 8, textAlign: 'left', borderBottom: '1px solid #ddd', backgroundColor: '#f2f2f2' } }, "Business Area"),
                        react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("th", { style: { padding: 8, textAlign: 'left', borderBottom: '1px solid #ddd', backgroundColor: '#f2f2f2' } }, "On Time"),
                        react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("th", { style: { padding: 8, textAlign: 'left', borderBottom: '1px solid #ddd', backgroundColor: '#f2f2f2' } }, "Overdue"))),
                react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("tbody", null, businessAreaWise.map(function (rows) {
                    return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("tr", null,
                        react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("td", { style: { padding: 8, textAlign: 'left', borderBottom: '1px solid #ddd' } }, rows === null || rows === void 0 ? void 0 : rows.businessArea),
                        react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("td", { style: { padding: 8, textAlign: 'left', borderBottom: '1px solid #ddd' } }, (rows === null || rows === void 0 ? void 0 : rows.completed) + (rows === null || rows === void 0 ? void 0 : rows.scheduled)),
                        react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("td", { style: { padding: 8, textAlign: 'left', borderBottom: '1px solid #ddd' } }, rows === null || rows === void 0 ? void 0 : rows.behind_schedule));
                }))))) : react__WEBPACK_IMPORTED_MODULE_0__["createElement"](react__WEBPACK_IMPORTED_MODULE_0__["Fragment"], null,
        react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("h3", null, "Production Board"),
        react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("table", { style: { borderCollapse: 'collapse', width: '100%' } },
            react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("thead", null,
                react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("tr", null,
                    react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("th", { style: { padding: 8, textAlign: 'left', borderBottom: '1px solid #ddd', backgroundColor: '#f2f2f2' } }, "Name"))),
            react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("tbody", null, productionBoard === null || productionBoard === void 0 ? void 0 : productionBoard.map(function (rows) {
                return react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("tr", null,
                    react__WEBPACK_IMPORTED_MODULE_0__["createElement"]("td", { style: { padding: 8, textAlign: 'left', borderBottom: '1px solid #ddd' } },
                        "Deveolper - id ", rows === null || rows === void 0 ? void 0 :
                        rows.DeveloperId));
            }))))));
};
/* harmony default export */ __webpack_exports__["default"] = (MainComponents);


/***/ }),

/***/ "mhxQ":
/*!**************************************************************************************!*\
  !*** ./lib/webparts/ggsaInnovationhubHelping/components/GgsaInnovationhubHelping.js ***!
  \**************************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react */ "cDcd");
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _MainComponents__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./MainComponents */ "krra");
var __extends = (undefined && undefined.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();


var GgsaInnovationhubHelping = /** @class */ (function (_super) {
    __extends(GgsaInnovationhubHelping, _super);
    function GgsaInnovationhubHelping() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    GgsaInnovationhubHelping.prototype.render = function () {
        console.log(this.props);
        return (react__WEBPACK_IMPORTED_MODULE_0__["createElement"](_MainComponents__WEBPACK_IMPORTED_MODULE_1__["default"], null));
    };
    return GgsaInnovationhubHelping;
}(react__WEBPACK_IMPORTED_MODULE_0__["Component"]));
/* harmony default export */ __webpack_exports__["default"] = (GgsaInnovationhubHelping);


/***/ })

/******/ })});;
//# sourceMappingURL=ggsa-innovationhub-helping-web-part.js.map