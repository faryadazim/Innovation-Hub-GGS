export interface IGgsaInnovationhubHelpingProps {
    description: string;
    isDarkTheme: boolean;
    environmentMessage: string;
    hasTeamsContext: boolean;
    userDisplayName: string;
}
//# sourceMappingURL=IGgsaInnovationhubHelpingProps.d.ts.map