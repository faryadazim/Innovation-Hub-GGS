import * as React from 'react';
import { IGgsaInnovationhubHelpingProps } from './IGgsaInnovationhubHelpingProps';
export default class GgsaInnovationhubHelping extends React.Component<IGgsaInnovationhubHelpingProps, {}> {
    render(): React.ReactElement<IGgsaInnovationhubHelpingProps>;
}
//# sourceMappingURL=GgsaInnovationhubHelping.d.ts.map