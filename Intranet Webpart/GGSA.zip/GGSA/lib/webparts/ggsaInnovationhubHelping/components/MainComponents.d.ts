/// <reference types="react" />
declare const MainComponents: () => JSX.Element;
export default MainComponents;
//# sourceMappingURL=MainComponents.d.ts.map