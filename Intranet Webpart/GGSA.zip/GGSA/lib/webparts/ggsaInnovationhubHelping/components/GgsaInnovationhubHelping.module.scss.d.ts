declare const styles: {
    ggsaInnovationhubHelping: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=GgsaInnovationhubHelping.module.scss.d.ts.map