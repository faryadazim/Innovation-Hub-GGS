/* tslint:disable */
require("./GgsaInnovationhubHelping.module.css");
const styles = {
  ggsaInnovationhubHelping: 'ggsaInnovationhubHelping_a78c2ad7',
  teams: 'teams_a78c2ad7',
  welcome: 'welcome_a78c2ad7',
  welcomeImage: 'welcomeImage_a78c2ad7',
  links: 'links_a78c2ad7'
};

export default styles;
/* tslint:enable */